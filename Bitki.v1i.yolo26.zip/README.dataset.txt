# Bitki > 2026-03-29 9:09am
https://universe.roboflow.com/selimws/bitki-rr2ed

Provided by a Roboflow user
License: CC BY 4.0

